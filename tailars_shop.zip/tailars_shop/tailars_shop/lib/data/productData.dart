


import 'package:tailars_shop/ecommerce/modelClass/productListmodel.dart';

class productdata{

  final List<productListModel> productlist = [
    productListModel(1, "Kuti Model", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 10, 2, 20, 500, 15, 'https://www.hatbazar365.com/wp-content/uploads/2020/10/Artificial-Leather-Jacket-for-Men-G11-JCK11-original.jpg'),
    productListModel(2, "Shart Model", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 33, 2, 20, 100, 25, 'https://bdmuhib24.files.wordpress.com/2021/10/men-s-winter-jacket-ati-002-1-original.jpeg'),
    productListModel(3, "Head Model", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 123, 2, 20, 100, 35, 'https://cdn.pixabay.com/photo/2016/01/12/11/01/mannequin-figure-1135180__480.jpg'),
    productListModel(4, "Up Model", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 456, 2, 20, 100, 45, 'https://cdn.pixabay.com/photo/2015/11/12/06/43/girl-1039729__340.jpg'),
    productListModel(5, "Up Model1", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 25, 2, 20, 100, 55, 'https://cdn.pixabay.com/photo/2020/12/08/20/34/girl-5815507__480.jpg'),
    productListModel(6, "Body Model", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 235, 2, 20, 100, 65, 'https://cdn.pixabay.com/photo/2018/11/30/07/16/woman-3847148__480.jpg'),
    productListModel(7, "T-Shart Model", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 235, 2, 20, 100, 75, 'https://cdn.pixabay.com/photo/2018/11/30/07/10/woman-3847130__480.jpg'),
    productListModel(8, "T-Shart Model2", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 235, 2, 20, 100, 85, 'https://cdn.pixabay.com/photo/2018/11/30/07/17/woman-3847150__480.jpg'),
    productListModel(9, "Gengi", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 345, 2, 20, 100, 95, 'https://cdn.pixabay.com/photo/2018/11/30/07/05/woman-3847118__340.jpg'),
    productListModel(10, "Women T-shart", "Taking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 455, 2, 20, 100, 125, 'https://cdn.pixabay.com/photo/2020/10/26/18/25/model-5688181__480.jpg'),
    productListModel(11, "Baby", "PTaking pre-order 50% advance must be payble RESTOCK OJC396 Royal Georget Semistiched Shirt With  Allover Sequence work n ghungaru work  Pure Banarsi Dupatta 🇨🇮shantoon bottom Shirt Size - 50 Lenth- 48", 655, 2, 20, 100, 235, 'https://cdn.pixabay.com/photo/2020/11/24/20/50/boy-5773919__480.jpg'),
  ];

}