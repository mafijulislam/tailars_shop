package com.jomshedali_sherpur.ict_appdevelopment_batch_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
